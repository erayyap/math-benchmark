def solve_card_flipping(k, n):
    """
    Solves the card flipping problem for k cards and n flips.

    Args:
      k: The number of cards (numbered 1 to k).
      n: The total number of flips.

    Returns:
      The sum of the numbers on the cards with their white side facing up.
    """

    cards = list(range(1, k + 1))  # Card numbers
    sides = [0] * k  # 0 represents white, 1 represents black
    flips = 0
    current_side = 0  # Start with white side

    while flips < n:
        flip_index = 0
        skip = False  # Flag to track skipping

        while flip_index < k and flips < n:
            if sides[flip_index] == current_side:
                if skip:
                    skip = False
                else:
                    sides[flip_index] = 1 - sides[flip_index]  # Flip the card
                    flips += 1
                    skip = True
            flip_index += 1

        # Check if all cards of the current side are flipped
        all_flipped = all(sides[i] != current_side for i in range(k))
        if all_flipped:
            current_side = 1 - current_side  # Switch to the other side

    # Calculate the sum of white-side-up cards
    white_sum = 0
    for i in range(k):
        if sides[i] == 0:
            white_sum += cards[i]

    return white_sum

# Example usage for the given question:
k = 1457
n = 97323 # Example N, you can change this to any desired value
result = solve_card_flipping(k, n)
print(f"After {n} flips, the sum of white-side-up cards is: {result}")