from itertools import combinations
import multiprocessing

phase1_countries = ["USA", "UK", "France", "Spain", "Iran", "Azerbaijan", "India", "China", "Algeria", "Botswana", "Egypt", "Japan", "Italy", "Portugal", "Gabon", "Ghana", "Germany", "Hungary"]
phase2_countries = ["Spain", "Iran", "Portugal", "Brazil", "South Africa", "Iraq", "Kazakhstan", "Cuba", "Croatia", "Bosnia and Herzegovina"]
phase3_countries = ["Brazil", "Portugal", "Saudi Arabia", "Greece", "Bulgaria", "Italy", "Croatia", "Denmark", "Qatar", "UAE", "USA"]
phase4_countries = ["Algeria", "South Africa", "El Salvador", "Finland", "Sweden", "Greece", "Hungary"]
phase5_countries = ["Croatia", "Spain", "Qatar", "El Salvador", "UK"]

# Generate all possible combinations for each phase
phase1_combinations = list(combinations(phase1_countries, 6))
phase2_combinations = list(combinations(phase2_countries, 4))
phase3_combinations = list(combinations(phase3_countries, 3))
phase4_combinations = list(combinations(phase4_countries, 2))
phase5_combinations = list(combinations(phase5_countries, 2))

def check_combinations(combo1, combo2_list, combo3_list, combo4_list, combo5_list):
    """Checks combinations for a given combo1 and returns the count of valid ways."""
    count = 0
    for combo2 in combo2_list:
        for combo3 in combo3_list:
            for combo4 in combo4_list:
                for combo5 in combo5_list:
                    combined_countries = list(combo1) + list(combo2) + list(combo3) + list(combo4) + list(combo5)
                    if len(set(combined_countries)) == 17:
                        count += 1
    return count

if __name__ == '__main__':
    # Use multiprocessing to distribute the work
    with multiprocessing.Pool() as pool:
        # Create a list of arguments for the check_combinations function
        args_list = [(combo1, phase2_combinations, phase3_combinations, phase4_combinations, phase5_combinations) for combo1 in phase1_combinations]

        # Use pool.starmap to apply check_combinations to each set of arguments
        results = pool.starmap(check_combinations, args_list)

    # Sum up the results from each process
    number_of_ways = sum(results)

    print(f"The number of different ways the company's list can be created is: {number_of_ways}")