from itertools import combinations

phase1_countries = ["USA", "UK", "France", "Spain", "Iran", "Azerbaijan"]
phase2_countries = ["Spain", "Iran", "Portugal", "Brazil", "South Africa"]
phase3_countries = ["Brazil", "Portugal", "Saudi Arabia", "Greece", "Bulgaria"]

# Generate all possible combinations for each phase
phase1_combinations = list(combinations(phase1_countries, 4))
phase2_combinations = list(combinations(phase2_countries, 3))
phase3_combinations = list(combinations(phase3_countries, 2))

# Initialize a counter for the number of valid ways
number_of_ways = 0

# Iterate through all combinations from each phase
for combo1 in phase1_combinations:
    for combo2 in phase2_combinations:
        for combo3 in phase3_combinations:
            # Combine the selected countries into a single list
            combined_countries = list(combo1) + list(combo2) + list(combo3)

            # Check if all countries in the combined list are unique
            if len(set(combined_countries)) == 9:
                number_of_ways += 1

print(f"The number of different ways the company's list can be created is: {number_of_ways}")